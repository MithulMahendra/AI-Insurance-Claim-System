import os
import psycopg
from psycopg.rows import dict_row
from dotenv import load_dotenv
from langchain.tools import tool

load_dotenv(override=True)

_RAW_CONN = os.getenv("PG_CONNECTION_STRING")

_COLLECTION_NAME = "policy_docs"

_FTS_SQL = """
    SELECT
        e.document                                               AS content,
        e.cmetadata                                              AS metadata,
        ts_rank(
            to_tsvector('english', e.document),
            plainto_tsquery('english', %(query)s)
        )                                                        AS fts_rank
    FROM  langchain_pg_embedding  e
    JOIN  langchain_pg_collection c ON c.uuid = e.collection_id
    WHERE c.name = %(collection)s
      AND to_tsvector('english', e.document)
          @@ plainto_tsquery('english', %(query)s)
    ORDER BY fts_rank DESC
    LIMIT %(k)s;
"""


@tool
def fts_search(query: str, k: int = 5) -> list[dict]:
    """
    Perform a full-text (keyword) search against the Policy knowledge base using
    PostgreSQL tsvector and ts_rank scoring.

    Use this tool when the query contains:
    - Policy or ticket codes  (e.g. 'POL-2024-HR-007')
    - Uppercase abbreviations (e.g. 'LTA', 'CTC', 'ESI')
    - Long employee/numeric IDs
    - Exact keyword matches

    Args:
        query: The user's search query (plain text).
        k:     Number of top results to return (default 5).

    Returns:
        A list of dicts with 'content', 'metadata', and 'fts_rank' keys.
    """
    print("Calling fts_search")
    with psycopg.connect(_RAW_CONN, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(
                _FTS_SQL,
                {"query": query, "collection": _COLLECTION_NAME, "k": k},
            )
            rows = cur.fetchall()
    return [
        {
            "content": row["content"],
            "metadata": row["metadata"],
            "fts_rank": round(float(row["fts_rank"]), 4),
        }
        for row in rows
    ]